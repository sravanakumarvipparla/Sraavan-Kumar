package com.qvc.couchbase.api.repository;

import org.springframework.data.couchbase.core.query.ViewIndexed;
import org.springframework.data.couchbase.repository.CouchbaseRepository;

import com.qvc.couchbase.api.model.SeasonCode;

@ViewIndexed(designDoc="seasonCode")
public interface SeasonCodeRepository extends CouchbaseRepository<SeasonCode, Long>{
	
}
