package com.qvc.couchbase.api.exception;

public class SeasonCodeNotFoundException extends Exception {
	private static final long serialVersionUID = 1L;
	
	public SeasonCodeNotFoundException(String message) {
		super(message);
	}
}

