package com.qvc.couchbase.api.service;

import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.qvc.couchbase.api.exception.SeasonCodeNotFoundException;
import com.qvc.couchbase.api.model.SeasonCode;
import com.qvc.couchbase.api.repository.SeasonCodeRepository;

@Service
public class SeasonCodeServiceImpl implements SeasonCodeService {
	
	@Autowired
	private SeasonCodeRepository seasonCodeRepository;

	@Override
	public SeasonCode saveSeasonCode(SeasonCode seasonCode) {
		Optional<SeasonCode> scode = seasonCodeRepository.findById(seasonCode.getId());
        
        if(scode.isPresent()) 
        {
        	SeasonCode newSeasonCode = scode.get();
        	newSeasonCode.setId(seasonCode.getId());
        	newSeasonCode.setName(seasonCode.getName());
        	newSeasonCode.setActive((seasonCode.getActive()));
        	newSeasonCode.setSeasonYear((seasonCode.getSeasonYear()));
        	newSeasonCode.setSeasonDescription((seasonCode.getSeasonDescription()));
        	newSeasonCode = seasonCodeRepository.save(newSeasonCode);      
            return newSeasonCode;
        } else {
        	seasonCode = seasonCodeRepository.save(seasonCode);
             
            return seasonCode;
        }
		
	}

	@Override
	public void removeSeasonCode(Long id) throws SeasonCodeNotFoundException {
		
		Optional<SeasonCode> seasonCode = seasonCodeRepository.findById(id);
        
        if(seasonCode.isPresent()) 
        {
        	seasonCodeRepository.deleteById(id);
        } else {
            throw new SeasonCodeNotFoundException("Season code details not present with this id ::::::"+id);
        }
		
	}

	@Override
	public List<SeasonCode> findAllSeasonCodes() throws SeasonCodeNotFoundException {
		List<SeasonCode> seasonCodeList= (List<SeasonCode>) seasonCodeRepository.findAll();
		 if(!seasonCodeList.isEmpty() ) {
	            return seasonCodeList;
	        } else {
	        	throw new SeasonCodeNotFoundException("No Season Code details are present to display");
	        }
	}
	@Override
	public SeasonCode getSeasonCodeById(Long id) throws SeasonCodeNotFoundException {

		Optional<SeasonCode> seasonCode = seasonCodeRepository.findById(id);
        
        if(seasonCode.isPresent()) {
            return seasonCode.get();
        } else {
            throw new SeasonCodeNotFoundException("No season code details found for  id "+ id);
        }
	}

}
