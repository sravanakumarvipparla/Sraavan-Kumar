package com.qvc.couchbase.api.controller;

import java.util.List;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.qvc.couchbase.api.exception.SeasonCodeNotFoundException;
import com.qvc.couchbase.api.model.SeasonCode;
import com.qvc.couchbase.api.service.SeasonCodeService;

@RestController
@RequestMapping(value = "/seasoncode")
public class SeasonCodeController {
	private static final Logger logger = LoggerFactory.getLogger(SeasonCodeController.class);
	@Autowired
	private SeasonCodeService seasonCodeService;
	
	@PostMapping(path = "/saveSeasonCode")
	@ResponseBody
	public ResponseEntity<SeasonCode> saveSeasonCodeOrUpdateSeasonCode(@Valid @RequestBody SeasonCode seasonCode) {
		logger.info("Inside save SeasonCodeOrUpdateSeasonCode.................");
		SeasonCode scode=seasonCodeService.saveSeasonCode(seasonCode);
		return new ResponseEntity<>(scode, new HttpHeaders(), HttpStatus.CREATED);
	}
	
	@DeleteMapping(path = "/{id}")
	public HttpStatus deleteSeasonCodes(@PathVariable("id") Long id) throws SeasonCodeNotFoundException {
		logger.info("Inside delete SeasonCodes.................");
		seasonCodeService.removeSeasonCode(id);
		return HttpStatus.FORBIDDEN;
	}

	@GetMapping(path = "/all")
	public ResponseEntity<List<SeasonCode>>  getAllSeasonCodes() throws SeasonCodeNotFoundException  {
		logger.info("Inside get All SeasonCodes.................");
		List<SeasonCode> scodeList= seasonCodeService.findAllSeasonCodes();
		return new ResponseEntity<>(scodeList, new HttpHeaders(), HttpStatus.OK);
	}
	@GetMapping("/{id}")
    public ResponseEntity<SeasonCode> getSeasonCodeById(@PathVariable("id") Long id) throws SeasonCodeNotFoundException {
		logger.info("Inside get SeasonCodeById.................");
		SeasonCode entity = seasonCodeService.getSeasonCodeById(id);
        return new ResponseEntity<>(entity, new HttpHeaders(), HttpStatus.OK);
    }
}
