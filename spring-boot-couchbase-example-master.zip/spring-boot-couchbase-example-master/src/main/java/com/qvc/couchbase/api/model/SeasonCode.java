package com.qvc.couchbase.api.model;

import javax.validation.constraints.NotEmpty;
import org.springframework.data.couchbase.core.mapping.Document;
import org.springframework.data.couchbase.core.mapping.id.GeneratedValue;
import org.springframework.data.couchbase.core.mapping.id.GenerationStrategy;

import com.couchbase.client.java.repository.annotation.Field;
import com.couchbase.client.java.repository.annotation.Id;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Document
@ToString
@Setter
@Getter
public class SeasonCode {
	@Id
	@GeneratedValue(strategy=GenerationStrategy.UNIQUE)
	private Long id;
	@Field
	@NotEmpty(message = "Please provide a name")
	private String name;
	
	@Field
	@NotEmpty(message = "Please provide a seasonDescription")
	private String seasonDescription;

	@Field
	@NotEmpty(message = "Please provide a seasonYear")
	private String seasonYear;
	
	@Field
	@NotEmpty(message = "Please provide a active status")
	private String active;
	
	public SeasonCode() {
		super();
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getSeasonDescription() {
		return seasonDescription;
	}
	public void setSeasonDescription(String seasonDescription) {
		this.seasonDescription = seasonDescription;
	}
	public String getSeasonYear() {
		return seasonYear;
	}
	public void setSeasonYear(String seasonYear) {
		this.seasonYear = seasonYear;
	}
	public String getActive() {
		return active;
	}
	public void setActive(String active) {
		this.active = active;
	}
	
	public SeasonCode(Long id, String name, String seasonDescription, String seasonYear, String active) {
		super();
		this.id = id;
		this.name = name;
		this.seasonDescription = seasonDescription;
		this.seasonYear = seasonYear;
		this.active = active;
	}
	
}
