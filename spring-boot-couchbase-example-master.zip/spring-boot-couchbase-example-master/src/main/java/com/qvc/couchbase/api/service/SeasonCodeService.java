package com.qvc.couchbase.api.service;

import java.util.List;

import com.qvc.couchbase.api.exception.SeasonCodeNotFoundException;
import com.qvc.couchbase.api.model.SeasonCode;

public interface SeasonCodeService {

	public SeasonCode saveSeasonCode(SeasonCode seasonCode);

	public void removeSeasonCode(Long id) throws SeasonCodeNotFoundException;

	public List<SeasonCode> findAllSeasonCodes()throws SeasonCodeNotFoundException;

	public SeasonCode getSeasonCodeById(Long id) throws SeasonCodeNotFoundException;

}
