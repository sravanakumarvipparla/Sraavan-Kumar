package com.qvc.couchbase.api.test.app;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.qvc.couchbase.api.SeasonCodeServiceCouchbaseApplication;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = SeasonCodeServiceCouchbaseApplication.class)
public class SeasonCodeAppTest {
	@Test
	public void contextLoads() {
	}

}
