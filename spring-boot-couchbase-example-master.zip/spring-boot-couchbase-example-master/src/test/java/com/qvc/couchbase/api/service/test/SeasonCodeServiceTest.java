package com.qvc.couchbase.api.service.test;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringRunner;

import com.qvc.couchbase.api.exception.SeasonCodeNotFoundException;
import com.qvc.couchbase.api.model.SeasonCode;
import com.qvc.couchbase.api.repository.SeasonCodeRepository;
import com.qvc.couchbase.api.service.SeasonCodeServiceImpl;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = SeasonCodeServiceImpl.class)
public class SeasonCodeServiceTest {
	
	@MockBean
	private SeasonCodeRepository seasonCodeRepository;
	
	@Autowired
	private SeasonCodeServiceImpl seasonCodeService;
	
	private static final long SEASON_CODE_ID=11l;
	private static final String SEASON_CODE_NAME="SC1";
	private static final String SEASON_CODE_DESC="DIWALI";
	private static final String SEASON_CODE_YEAR="2020";
	private static final String SEASON_CODE_ACTIVE="Y";
	
	@Test
	public void testCreateSeasonCode() {
		SeasonCode seasonCode = buildSeasonCodeRequest();
	
		when(seasonCodeRepository.save(seasonCode)).thenReturn(seasonCode);
		SeasonCode seasonCodeResponse = seasonCodeService.saveSeasonCode(seasonCode);

		assertThat(seasonCodeResponse.getId()).isEqualTo(seasonCode.getId());

	}
	
	@Test
	public void testFindAllSeasonCodes() throws SeasonCodeNotFoundException {

		List<SeasonCode> seasonCodeList = buildSeasonCodeList();
		when(seasonCodeRepository.findAll()).thenReturn(seasonCodeList);
		List<SeasonCode> response = seasonCodeService.findAllSeasonCodes();
		assertThat(response).isNotEmpty();

	}
	
	@Test
	public void testGetSeasonCodeById() throws SeasonCodeNotFoundException {

		SeasonCode seasonCode = buildSeasonCodeRequest();
		when(seasonCodeRepository.findById(seasonCode.getId())).thenReturn(Optional.ofNullable(seasonCode));
		SeasonCode response = seasonCodeService.getSeasonCodeById(seasonCode.getId());
		assertThat(response.getId()).isEqualTo(seasonCode.getId());
		assertThat(response).isNotNull();

	}
	
	@Test
	public void testdeleteSeasonCodeById() {
		Long id = 11l;
		Mockito.doNothing().when(seasonCodeRepository).deleteById(id);
	}
	
	private SeasonCode buildSeasonCodeRequest() {
		SeasonCode sc=new SeasonCode();
		sc.setId(SEASON_CODE_ID);
		sc.setName(SEASON_CODE_NAME);
		sc.setSeasonDescription(SEASON_CODE_DESC);
		sc.setSeasonYear(SEASON_CODE_YEAR);
		sc.setActive(SEASON_CODE_ACTIVE);
		return sc;
	}
	
	private List<SeasonCode> buildSeasonCodeList() {
		List<SeasonCode> scodesList = new ArrayList<>();
	    scodesList.add(buildSeasonCodeRequest());
		return scodesList;
	}
	
	
	@Test(expected=SeasonCodeNotFoundException.class)
	public void testGetSeasonCodeByIdThowsSeasoncodeNotFoundException() throws SeasonCodeNotFoundException {
		SeasonCode seasonCode = buildSeasonCodeRequest();
		Optional<SeasonCode> emptySeasonCode = Optional.empty();
		when(seasonCodeRepository.findById(seasonCode.getId())).thenReturn(emptySeasonCode);
		seasonCodeService.getSeasonCodeById(seasonCode.getId());
	}
	
	@Test(expected=SeasonCodeNotFoundException.class)
	public void testFindAllSeasonCodesThowsSeasoncodeNotFoundException() throws SeasonCodeNotFoundException {
		List<SeasonCode> seasonCodeList = buildSeasonCodeList();
		seasonCodeList.clear();
		when(seasonCodeRepository.findAll()).thenReturn(seasonCodeList);
		seasonCodeService.findAllSeasonCodes();

	}
	
	@Test(expected=SeasonCodeNotFoundException.class)
	public void testdeleteSeasonCodeByIdThowsSeasoncodeNotFoundException() throws SeasonCodeNotFoundException {
		SeasonCode seasonCode = buildSeasonCodeRequest();
		Optional<SeasonCode> emptySeasonCode = Optional.empty();
		when(seasonCodeRepository.findById(seasonCode.getId())).thenReturn(emptySeasonCode);
		seasonCodeService.removeSeasonCode(seasonCode.getId());
	}
	
	@Test
	public void testUpdateSeasonCode() {
		SeasonCode seasonCode = buildSeasonCodeRequest();
		when(seasonCodeRepository.findById(seasonCode.getId())).thenReturn(Optional.of(seasonCode));
		seasonCodeService.saveSeasonCode(seasonCode);
	}
}
