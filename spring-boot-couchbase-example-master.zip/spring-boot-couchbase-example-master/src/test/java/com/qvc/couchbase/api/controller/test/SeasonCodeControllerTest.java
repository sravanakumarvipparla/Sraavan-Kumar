package com.qvc.couchbase.api.controller.test;

import static org.hamcrest.CoreMatchers.hasItem;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.notNullValue;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.ArrayList;
import java.util.List;

import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.MethodSorters;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectWriter;
import com.qvc.couchbase.api.controller.SeasonCodeController;
import com.qvc.couchbase.api.exception.SeasonCodeNotFoundException;
import com.qvc.couchbase.api.model.SeasonCode;
import com.qvc.couchbase.api.service.SeasonCodeServiceImpl;

@RunWith(SpringRunner.class)
@WebMvcTest(value = SeasonCodeController.class, secure = false)
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class SeasonCodeControllerTest {
	
	@Autowired
	private MockMvc mockMvc;
	@MockBean
	private SeasonCodeServiceImpl seasonCodeServiceImpl;
	
	private static final String SEASON_CODE="/seasoncode/";
	
	private static final long SEASON_CODE_ID=11l;
	private static final String SEASON_CODE_NAME="SC1";
	private static final String SEASON_CODE_DESC="SC1";
	private static final String SEASON_CODE_YEAR="2020";
	private static final String SEASON_CODE_ACTIVE="Y";

	@Test
	public void findAllSeasonCodesTest() throws Exception {
		List<SeasonCode> seasonCodeList = buildSeasonCodeList();
		when(seasonCodeServiceImpl.findAllSeasonCodes()).thenReturn(seasonCodeList);
		mockMvc.perform(MockMvcRequestBuilders.get(SEASON_CODE+"all").accept(MediaType.APPLICATION_JSON).
		contentType(MediaType.APPLICATION_JSON)).andExpect(status().isOk()).andExpect(MockMvcResultMatchers.jsonPath("$[0].id").value(seasonCodeList.get(0).getId()));
	}
	
	@Test
	public void retriveSeasonCodeByIdTest() throws Exception {
		SeasonCode seasonCodeRequest = buildSeasonCodeRequest();
		SeasonCode seasonCodeResponse = buildSeasonCodeResponse();
		when(seasonCodeServiceImpl.getSeasonCodeById(seasonCodeRequest.getId())).thenReturn(seasonCodeResponse);
		mockMvc.perform(MockMvcRequestBuilders.get(SEASON_CODE+seasonCodeRequest.getId()).accept(MediaType.APPLICATION_JSON).
		contentType(MediaType.APPLICATION_JSON)).andExpect(status().isOk()).andExpect(MockMvcResultMatchers.jsonPath("$.id").value(seasonCodeRequest.getId()));
	}
	
	@Test
	public void createSeasonCode() throws Exception {
		SeasonCode seasonCodeRequest = buildSeasonCodeRequest();
		SeasonCode seasonCodeResponse = buildSeasonCodeResponse();
		when(seasonCodeServiceImpl.saveSeasonCode(seasonCodeRequest)).thenReturn(seasonCodeResponse); 
		mockMvc.perform(MockMvcRequestBuilders.post(SEASON_CODE+"saveSeasonCode").accept(MediaType.APPLICATION_JSON)
				.content(getJson(seasonCodeRequest)).contentType(MediaType.APPLICATION_JSON_UTF8)).andExpect(status().isCreated());		
	}
	
	@Test
	public void removeSeasonCodeByIdTest() throws Exception {
		SeasonCode seasonCodeRequest = buildSeasonCodeRequest();
		Mockito.doNothing().when(this.seasonCodeServiceImpl).removeSeasonCode(seasonCodeRequest.getId());
		mockMvc.perform(MockMvcRequestBuilders.delete(SEASON_CODE+seasonCodeRequest.getId()).accept(MediaType.APPLICATION_JSON).
				contentType(MediaType.APPLICATION_JSON)).andExpect(status().isOk());
	}
	@Test
	public void findSeasonCodeByIdThrowsSeasonCodeNotFoundException() throws Exception {
		SeasonCode seasonCodeRequest = buildSeasonCodeRequest();
		when(seasonCodeServiceImpl.getSeasonCodeById(seasonCodeRequest.getId())).thenThrow(SeasonCodeNotFoundException.class);
		mockMvc.perform(MockMvcRequestBuilders.get(SEASON_CODE+seasonCodeRequest.getId()).accept(MediaType.APPLICATION_JSON).
		contentType(MediaType.APPLICATION_JSON)).andExpect(status().is4xxClientError());
	}
	
	@Test
	public void testCreateSeasonCodeInvalidRequest() throws Exception {
		SeasonCode seasonCodeRequest = buildSeasonCodeRequest();
		seasonCodeRequest.setName("");
		SeasonCode seasonCodeResponse = buildSeasonCodeResponse();
		when(seasonCodeServiceImpl.saveSeasonCode(seasonCodeRequest)).thenReturn(seasonCodeResponse); 
		mockMvc.perform(MockMvcRequestBuilders.post(SEASON_CODE+"saveSeasonCode").accept(MediaType.APPLICATION_JSON)
				.content(getJson(seasonCodeRequest)).contentType(MediaType.APPLICATION_JSON_UTF8)).andExpect(status().is4xxClientError()).andExpect(jsonPath("$.timestamp", is(notNullValue())))
        .andExpect(jsonPath("$.status", is(400)))
        .andExpect(jsonPath("$.errors").isArray())
        .andExpect(jsonPath("$.errors", hasItem("Please provide a name")));
	}
	
	@Test
	public void removeSeasonCodeByInvalidIdTest() throws Exception {
		SeasonCode seasonCodeRequest = buildSeasonCodeRequest();
		Mockito.doNothing().when(this.seasonCodeServiceImpl).removeSeasonCode(seasonCodeRequest.getId());
		mockMvc.perform(MockMvcRequestBuilders.delete(SEASON_CODE+"fff").accept(MediaType.APPLICATION_JSON).
				contentType(MediaType.APPLICATION_JSON)).andExpect(status().is4xxClientError());
	}
	
	
	@Test
	public void getSeasonCodeByInvalidIdTest() throws Exception {
		mockMvc.perform(MockMvcRequestBuilders.get(SEASON_CODE+"/fff").accept(MediaType.APPLICATION_JSON).
				contentType(MediaType.APPLICATION_JSON)).andExpect(status().is4xxClientError());
	}
	
	private List<SeasonCode> buildSeasonCodeList() {
		List<SeasonCode> scodesList = new ArrayList<>();
	    scodesList.add(buildSeasonCodeRequest());
		return scodesList;
	}
	
	private byte[] getJson(Object seasonCodeRequest) throws JsonProcessingException {
		ObjectWriter ow = new ObjectMapper().writer().withDefaultPrettyPrinter();
		String json = ow.writeValueAsString(seasonCodeRequest);
		return json.getBytes();
	}
	
	private SeasonCode buildSeasonCodeRequest() {
		SeasonCode sc=new SeasonCode();
		sc.setId(SEASON_CODE_ID);
		sc.setName(SEASON_CODE_NAME);
		sc.setSeasonDescription(SEASON_CODE_DESC);
		sc.setSeasonYear(SEASON_CODE_YEAR);
		sc.setActive(SEASON_CODE_ACTIVE);
		return sc;
	}
	
	private SeasonCode buildSeasonCodeResponse() {
		SeasonCode sc=new SeasonCode();
		sc.setId(SEASON_CODE_ID);
		return sc;
	}
	
}
