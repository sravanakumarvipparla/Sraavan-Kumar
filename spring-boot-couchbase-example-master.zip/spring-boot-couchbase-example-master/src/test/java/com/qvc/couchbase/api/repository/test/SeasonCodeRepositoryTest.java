package com.qvc.couchbase.api.repository.test;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertSame;
import java.util.Optional;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.qvc.couchbase.api.model.SeasonCode;
import com.qvc.couchbase.api.repository.SeasonCodeRepository;


@RunWith(SpringRunner.class)
@SpringBootTest
public class SeasonCodeRepositoryTest {
	
	@Autowired
	private SeasonCodeRepository seasonCodeRepository;
	
	@Test
	public void findSeasonCodeById() {
		SeasonCode seasonCodeRequest = buildSeasonCodeRequest();
		Optional<SeasonCode> seasonCode=seasonCodeRepository.findById(seasonCodeRequest.getId());
		assertNotNull(seasonCode);
	}
	
	@Test
	public void saveSeasonCode() {
		SeasonCode seasonCodeRequest = buildSeasonCodeRequest();
		SeasonCode seasonCode=seasonCodeRepository.save(seasonCodeRequest);
		assertSame(seasonCodeRequest.getId(), seasonCode.getId());   
	}
	
	@Test
	public void findAllSeasonCodes() {
		    SeasonCode seasonCode =new SeasonCode(11l, "SC1", "Diwali", "2020", "Y");
		    seasonCodeRepository.save(seasonCode);
	        assertNotNull(seasonCodeRepository.findAll());
	}
	
	@Test
	public void deleteSeasonCodeById() {
		    SeasonCode seasonCode =new SeasonCode(11l, "SC1", "Diwali", "2020", "Y");
		    seasonCodeRepository.save(seasonCode);
		    seasonCodeRepository.deleteById(seasonCode.getId());
	}
	
	private SeasonCode buildSeasonCodeRequest() {
		SeasonCode sc=new SeasonCode();
		sc.setId(11l);
		sc.setName("SC1");
		sc.setSeasonDescription("DIWLI");
		sc.setSeasonYear("2020");
		sc.setActive("Y");
		return sc;
	}
}
