package com.qvc.couchbase.api.integration.test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.io.IOException;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringRunner;

import com.qvc.couchbase.api.SeasonCodeServiceCouchbaseApplication;
import com.qvc.couchbase.api.model.SeasonCode;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = SeasonCodeServiceCouchbaseApplication.class, webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
public class SeasonCodeServiceIntegrationTest {
	@LocalServerPort
	private int port;

	TestRestTemplate restTemplate = new TestRestTemplate();

	HttpHeaders headers = new HttpHeaders();
	private static final long SEASON_CODE_ID=11l;
	private static final String SEASON_CODE_NAME="SC1";
	private static final String SEASON_CODE_DESC="DIWALI";
	private static final String SEASON_CODE_YEAR="2020";
	private static final String SEASON_CODE_ACTIVE="Y";
	
	
	@Test
	public void createSeasonCodes() throws IOException {

		SeasonCode seasoncode = buildSeasonCodeRequest();
		headers.setContentType(MediaType.APPLICATION_JSON);

		HttpEntity<SeasonCode> entity = new HttpEntity<>(seasoncode, headers);
		ResponseEntity<SeasonCode> response = restTemplate.exchange(createURLWithPort("/seasoncode/saveSeasonCode"),
				HttpMethod.POST, entity, SeasonCode.class);
		assertEquals(201, response.getStatusCodeValue());
		assertNotNull(response.getBody());
	}

	@Test
	public void testRetriveSeasonCodesById() throws IOException {
		headers.setContentType(MediaType.APPLICATION_JSON);
		SeasonCode seasoncode = buildSeasonCodeRequest();
		HttpEntity<String> entity = new HttpEntity<>(null, headers);

		ResponseEntity<String> response = restTemplate.exchange(createURLWithPort("seasoncode/" + seasoncode.getId()),
				HttpMethod.GET, entity, String.class);
		assertEquals(200, response.getStatusCodeValue());
        assertNotNull(response.getBody());

	}

	@Test
	public void testRetrieveAllSeasonCodes() throws IOException {
		headers.setContentType(MediaType.APPLICATION_JSON);

		HttpEntity<String> entity = new HttpEntity<>(null, headers);

		ResponseEntity<String> response = restTemplate.exchange(createURLWithPort("seasoncode/all"), HttpMethod.GET,
				entity, String.class);
		assertNotNull(response.getBody());
		assertEquals(200, response.getStatusCodeValue());
	}
	
	
	@Test
	public void testRemoveSeasonCodesById() {
		headers.setContentType(MediaType.APPLICATION_JSON);
		SeasonCode seasoncode = buildSeasonCodeRequest();
		HttpEntity<String> entity = new HttpEntity<>(null, headers);

		ResponseEntity<String> response = restTemplate.exchange(createURLWithPort("seasoncode/"+seasoncode.getId()), HttpMethod.DELETE,
				entity, String.class);
		assertNotNull(response.getBody());
	}

	@Test
    public void createSeasonCodesInvalidInput() {
		SeasonCode seasoncode = buildSeasonCodeRequest();
		seasoncode.setName("");
		headers.setContentType(MediaType.APPLICATION_JSON);
		HttpEntity<SeasonCode> entity = new HttpEntity<>(seasoncode, headers);

		ResponseEntity<String> response = restTemplate.exchange(createURLWithPort("seasoncode/saveSeasonCode"),
				HttpMethod.POST, entity, String.class);
		 assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());

    }

	private SeasonCode buildSeasonCodeRequest() {
		SeasonCode sc = new SeasonCode();
		sc.setId(SEASON_CODE_ID);
		sc.setName(SEASON_CODE_NAME);
		sc.setSeasonDescription(SEASON_CODE_DESC);
		sc.setSeasonYear(SEASON_CODE_YEAR);
		sc.setActive(SEASON_CODE_ACTIVE);
		return sc;
	}

	private String createURLWithPort(String uri) {
		return "http://localhost:" + port + uri;
	}

}
