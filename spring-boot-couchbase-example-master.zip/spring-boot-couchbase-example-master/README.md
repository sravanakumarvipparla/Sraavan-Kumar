# spring-boot-couchbase-example
How to use Couchbase Database with Spring Boot
