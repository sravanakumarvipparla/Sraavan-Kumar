package com.qvc.buyer.app.model;

import javax.validation.constraints.NotEmpty;

import org.springframework.data.couchbase.core.mapping.Document;
import org.springframework.data.couchbase.core.mapping.id.GeneratedValue;
import com.couchbase.client.java.repository.annotation.Field;
import com.couchbase.client.java.repository.annotation.Id;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;
import lombok.experimental.Accessors;

@Document
@Setter
@Getter
@Accessors
@AllArgsConstructor
public class Buyer {
	@Id
	@GeneratedValue
	private Long id;
	
	@Field
	@NotEmpty(message = "Please provide a buyerCode")
	private String buyerCode;
	@Field
	@NotEmpty(message = "Please provide a buyerDescription")
	private String buyerDescription;
	@NotEmpty(message = "Please provide a userId")
	private String userId;
	@NotEmpty(message = "Please provide a active")
	private String active;
	@NotEmpty(message = "Please provide a directorCode")
	private String directorCode;
	@NotEmpty(message = "Please provide a directorDescription")
	private String directorDescription;
	@NotEmpty(message = "Please provide a vpCode")
	private String vpCode;
	@NotEmpty(message = "Please provide a vpDescription")
	private String vpDescription;
	@NotEmpty(message = "Please provide a sales")
	private String sales;
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getBuyerCode() {
		return buyerCode;
	}
	public void setBuyerCode(String buyerCode) {
		this.buyerCode = buyerCode;
	}
	public String getBuyerDescription() {
		return buyerDescription;
	}
	public void setBuyerDescription(String buyerDescription) {
		this.buyerDescription = buyerDescription;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getActive() {
		return active;
	}
	public void setActive(String active) {
		this.active = active;
	}
	public String getDirectorCode() {
		return directorCode;
	}
	public void setDirectorCode(String directorCode) {
		this.directorCode = directorCode;
	}
	public String getDirectorDescription() {
		return directorDescription;
	}
	public void setDirectorDescription(String directorDescription) {
		this.directorDescription = directorDescription;
	}
	public String getVpCode() {
		return vpCode;
	}
	public void setVpCode(String vpCode) {
		this.vpCode = vpCode;
	}
	public String getVpDescription() {
		return vpDescription;
	}
	public void setVpDescription(String vpDescription) {
		this.vpDescription = vpDescription;
	}
	public String getSales() {
		return sales;
	}
	public void setSales(String sales) {
		this.sales = sales;
	}
	
}
