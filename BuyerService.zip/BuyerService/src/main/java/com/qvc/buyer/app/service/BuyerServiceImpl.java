package com.qvc.buyer.app.service;

import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.qvc.buyer.app.exception.BuyerDetailsNotFoundException;
import com.qvc.buyer.app.model.Buyer;
import com.qvc.buyer.app.repository.BuyerRepository;

@Service
public class BuyerServiceImpl implements BuyerService {
	
	@Autowired
	private BuyerRepository buyerRepository;

	@Override
	public Buyer saveBuyer(Buyer buyer) {
    Optional<Buyer> bcode = buyerRepository.findById(buyer.getId());
        
        if(bcode.isPresent()) 
        {
        	Buyer newbuyerCode = bcode.get();
        	newbuyerCode.setId(buyer.getId());
        	newbuyerCode.setBuyerCode(buyer.getBuyerCode());
        	newbuyerCode.setBuyerDescription(buyer.getBuyerDescription());
        	newbuyerCode.setUserId(buyer.getUserId());
        	newbuyerCode.setActive(buyer.getActive());
        	newbuyerCode.setDirectorCode(buyer.getDirectorCode());
        	newbuyerCode.setDirectorDescription(buyer.getBuyerDescription());
        	newbuyerCode.setVpCode(buyer.getVpCode());
        	newbuyerCode.setVpDescription(buyer.getVpDescription());
        	newbuyerCode.setSales(buyer.getSales());
        	newbuyerCode = buyerRepository.save(newbuyerCode);      
            return newbuyerCode;
        } else {
           buyer = buyerRepository.save(buyer);
             
            return buyer;
        }
	}

	@Override
	public void removeBuyer(Long id) throws BuyerDetailsNotFoundException {
    Optional<Buyer> buyerCode = buyerRepository.findById(id);
        
        if(buyerCode.isPresent()) 
        {
        	buyerRepository.deleteById(id);
        } else {
            throw new BuyerDetailsNotFoundException("Buyer  details not present with this id ::::::"+id);
        }
	}

	@Override
	public List<Buyer> findAllBuyers() throws BuyerDetailsNotFoundException {
		List<Buyer> buyerList= (List<Buyer>) buyerRepository.findAll();
		 if(!buyerList.isEmpty() ) {
	            return buyerList;
	        } else {
	        	throw new BuyerDetailsNotFoundException("No Buyer details are present to display");
	        }
	}

	@Override
	public Buyer getBuyerById(Long id) throws BuyerDetailsNotFoundException {
	Optional<Buyer> buyerCode = buyerRepository.findById(id);
        
        if(buyerCode.isPresent()) {
            return buyerCode.get();
        } else {
            throw new BuyerDetailsNotFoundException("No Buyer details found for  id "+ id);
        }
	}

}
