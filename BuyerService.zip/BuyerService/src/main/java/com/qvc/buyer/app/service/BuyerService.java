package com.qvc.buyer.app.service;

import java.util.List;

import com.qvc.buyer.app.exception.BuyerDetailsNotFoundException;
import com.qvc.buyer.app.model.Buyer;


public interface BuyerService {
	
	public Buyer saveBuyer(Buyer buyer);

	public void removeBuyer(Long id) throws BuyerDetailsNotFoundException;

	public List<Buyer> findAllBuyers()throws BuyerDetailsNotFoundException;

	public Buyer getBuyerById(Long id) throws BuyerDetailsNotFoundException;
	

}
