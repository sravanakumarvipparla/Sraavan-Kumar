package com.qvc.buyer.app.exception;

public class BuyerDetailsNotFoundException extends Exception {
	private static final long serialVersionUID = 1L;
	
	public BuyerDetailsNotFoundException(String message) {
		super(message);
	}
}

