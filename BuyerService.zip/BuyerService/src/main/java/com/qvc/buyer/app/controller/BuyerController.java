package com.qvc.buyer.app.controller;

import java.util.List;
import javax.validation.Valid;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.qvc.buyer.app.exception.BuyerDetailsNotFoundException;
import com.qvc.buyer.app.model.Buyer;
import com.qvc.buyer.app.service.BuyerService;

@RestController
@RequestMapping(value = "/buyer")
public class BuyerController {
	private static final Logger logger = LoggerFactory.getLogger(BuyerController.class);
	@Autowired
	private BuyerService buyerService;
	
	@PostMapping(path = "/saveBuyer")
	@ResponseBody
	public ResponseEntity<Buyer> saveBuyerOrUpdateBuyer(@Valid @RequestBody Buyer buyer) {
		logger.info("Inside save BuyerOrUpdateBuyer.................");
		Buyer bcode=buyerService.saveBuyer(buyer);
		return new ResponseEntity<>(bcode, new HttpHeaders(), HttpStatus.CREATED);
	}
	
	@DeleteMapping(path = "/{id}")
	public HttpStatus deleteBuyers(@PathVariable("id") Long id) throws BuyerDetailsNotFoundException {
		logger.info("Inside delete Buyers.................");
		buyerService.removeBuyer(id);
		return HttpStatus.FORBIDDEN;
	}

	@GetMapping(path = "/all")
	public ResponseEntity<List<Buyer>>  getAllBuyers() throws BuyerDetailsNotFoundException  {
		logger.info("Inside get All Buyers.................");
		List<Buyer> bcodeList= buyerService.findAllBuyers();
		return new ResponseEntity<>(bcodeList, new HttpHeaders(), HttpStatus.OK);
	}
	@GetMapping("/{id}")
    public ResponseEntity<Buyer> getBuyerById(@PathVariable("id") Long id) throws BuyerDetailsNotFoundException {
		logger.info("Inside get BuyerById.................");
		Buyer entity = buyerService.getBuyerById(id);
        return new ResponseEntity<>(entity, new HttpHeaders(), HttpStatus.OK);
    }
}
