package com.qvc.buyer.app.repository;

import org.springframework.data.couchbase.core.query.ViewIndexed;
import org.springframework.data.couchbase.repository.CouchbaseRepository;
import org.springframework.stereotype.Repository;

import com.qvc.buyer.app.model.Buyer;

@Repository
@ViewIndexed(designDoc="buyer")
public interface BuyerRepository extends CouchbaseRepository<Buyer, Long> {

}
