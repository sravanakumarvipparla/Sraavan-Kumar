package com.qvc.buyer.app.service;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringRunner;

import com.qvc.buyer.app.exception.BuyerDetailsNotFoundException;
import com.qvc.buyer.app.model.Buyer;
import com.qvc.buyer.app.repository.BuyerRepository;


@RunWith(SpringRunner.class)
@SpringBootTest(classes = BuyerServiceImpl.class)
public class BuyerCodeServiceTest {
	
	@MockBean
	private BuyerRepository buyerRepository;
	
	@Autowired
	private BuyerServiceImpl buyerService;
	
	@Test
	public void testCreateBuyer() {
		Buyer buyer = buildBuyerRequest();
		when(buyerRepository.save(buyer)).thenReturn(buyer);
		Buyer buyerResponse = buyerService.saveBuyer(buyer);
       assertThat(buyer.getId().toString()).isEqualTo(buyerResponse.getId().toString());

	}
	
	@Test
	public void testFindAllBuyers() throws BuyerDetailsNotFoundException {

		List<Buyer> buyerList = buildBuyerList();
		when(buyerRepository.findAll()).thenReturn(buyerList);
		List<Buyer> response = buyerService.findAllBuyers();
		assertThat(response).isNotEmpty();

	}
	
	@Test
	public void testRetriveBuyerById() throws BuyerDetailsNotFoundException {

		Buyer buyer = buildBuyerRequest();
		when(buyerRepository.findById(buyer.getId())).thenReturn(Optional.ofNullable(buyer));
		Buyer response = buyerService.getBuyerById(buyer.getId());
		assertThat(response.getId()).isEqualTo(buyer.getId());
		assertThat(response).isNotNull();

	}
	
	@Test
	public void testDelteBuyerById() throws BuyerDetailsNotFoundException {
		Buyer buyer = buildBuyerRequest();
		when(buyerRepository.findById(buyer.getId())).thenReturn(Optional.ofNullable(buyer));
		//Mockito.doNothing().when(buyerRepository).deleteById(id);
		 buyerService.removeBuyer(buyer.getId());
	}
	
	private List<Buyer> buildBuyerList() {
		List<Buyer> buyerList = new ArrayList<>();
		buyerList.add(buildBuyerRequest());
		return buyerList;
	}
	
	@Test(expected=BuyerDetailsNotFoundException.class)
	public void testGetBuyerByIdThowsBuyerDetailsNotFoundException() throws BuyerDetailsNotFoundException {
		Buyer buyer = buildBuyerRequest();
		Optional<Buyer> emptyBuyer = Optional.empty();
		when(buyerRepository.findById(buyer.getId())).thenReturn(emptyBuyer);
		buyerService.getBuyerById(buyer.getId());
	}
	
	@Test(expected=BuyerDetailsNotFoundException.class)
	public void testFindAllBuyersThowsBuyerDetailsNotFoundException() throws BuyerDetailsNotFoundException {
		List<Buyer> buyerList = buildBuyerList();
		buyerList.clear();
		when(buyerRepository.findAll()).thenReturn(buyerList);
		buyerService.findAllBuyers();

	}
	
	@Test(expected=BuyerDetailsNotFoundException.class)
	public void testdeleteBuyerByIdThowsBuyerDetailsNotFoundException() throws BuyerDetailsNotFoundException {
		Buyer buyer = buildBuyerRequest();
		Optional<Buyer> emptyBuyer = Optional.empty();
		when(buyerRepository.findById(buyer.getId())).thenReturn(emptyBuyer);
		buyerService.removeBuyer(buyer.getId());
	}
	
	@Test
	public void testUpdateBuyer() {
		Buyer buyer = buildBuyerRequest();
		when(buyerRepository.findById(buyer.getId())).thenReturn(Optional.of(buyer));
		buyerService.saveBuyer(buyer);
	}
	
	private Buyer buildBuyerRequest() {
		Buyer buyer=new Buyer();
		buyer.setId(213l);
		buyer.setBuyerCode("Co1");
		buyer.setBuyerDescription("PCPR5310buyer");
		buyer.setUserId("q134758");
		buyer.setActive("Y");
		buyer.setDirectorCode("077");
		buyer.setDirectorDescription("PCRP5310dir");
		buyer.setVpCode("111");
		buyer.setVpDescription("530");
		buyer.setSales("qvc");
		return buyer;
	}

}
