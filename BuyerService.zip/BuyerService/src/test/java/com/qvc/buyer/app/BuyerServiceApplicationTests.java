package com.qvc.buyer.app;


import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.qvc.buyer.app.BuyerServiceApplication;


@RunWith(SpringRunner.class)
@SpringBootTest(classes = BuyerServiceApplication.class)
public class BuyerServiceApplicationTests {

	@Test
	public void contextLoads() {
	}

}
