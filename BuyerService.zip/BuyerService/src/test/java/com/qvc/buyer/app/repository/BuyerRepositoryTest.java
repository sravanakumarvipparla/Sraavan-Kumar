package com.qvc.buyer.app.repository;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertSame;

import java.util.List;
import java.util.Optional;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.qvc.buyer.app.model.Buyer;

@RunWith(SpringRunner.class)
@SpringBootTest
public class BuyerRepositoryTest {
	
	
	@Autowired
	private BuyerRepository buyerRepository;
	
	@Test
	public void saveBuyer() {
		Buyer buyerRequest = buildBuyerRequest();
		Buyer buyer=buyerRepository.save(buyerRequest);
		assertSame(buyerRequest.getId(), buyer.getId());   
		
	}
	
	@Test
	public void findBuyerById() {
		Buyer buyerRequest = buildBuyerRequest();
		buyerRepository.save(buyerRequest);
		Optional<Buyer> buyer=buyerRepository.findById(buyerRequest.getId());
		assertNotNull(buyer);
		assertEquals(buyerRequest.getId().toString(), buyer.get().getId().toString());   
	}
	
	@Test
	public void findAllBuyers() {
		Buyer buyerRequest = buildBuyerRequest();
		buyerRepository.save(buyerRequest);
		List<Buyer> buyers=(List<Buyer>) buyerRepository.findAll();
		assertNotNull(buyers);
	}
	
	@Test
	public void deleteBuyerById() {
		Buyer buyerRequest = buildBuyerRequest();
		buyerRepository.save(buyerRequest);
		buyerRepository.deleteById(buyerRequest.getId());
	}
	
	private Buyer buildBuyerRequest() {
		Buyer buyer=new Buyer();
		buyer.setId(213l);
		buyer.setBuyerCode("Co1");
		buyer.setBuyerDescription("PCPR5310buyer");
		buyer.setUserId("q134758");
		buyer.setActive("Y");
		buyer.setDirectorCode("077");
		buyer.setDirectorDescription("PCRP5310dir");
		buyer.setVpCode("111");
		buyer.setVpDescription("530");
		buyer.setSales("qvc");
		return buyer;
	}
	
	
}
