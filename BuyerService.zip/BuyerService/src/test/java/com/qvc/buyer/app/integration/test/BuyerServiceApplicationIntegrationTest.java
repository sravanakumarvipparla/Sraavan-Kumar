package com.qvc.buyer.app.integration.test;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringRunner;
import com.qvc.buyer.app.BuyerServiceApplication;
import com.qvc.buyer.app.model.Buyer;


@RunWith(SpringRunner.class)
@SpringBootTest(classes = BuyerServiceApplication.class, webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
public class BuyerServiceApplicationIntegrationTest {
	@LocalServerPort
	private int port;

	TestRestTemplate restTemplate = new TestRestTemplate();

	HttpHeaders headers = new HttpHeaders();
	
	@Test
	public void createBuyer()  {
		Buyer buyer = buildBuyerRequest();
		headers.setContentType(MediaType.APPLICATION_JSON);

		HttpEntity<Buyer> entity = new HttpEntity<>(buyer, headers);
		ResponseEntity<Buyer> response = restTemplate.exchange(createURLWithPort("/buyer/saveBuyer"),
				HttpMethod.POST, entity, Buyer.class);
		assertNotNull(response.getBody());
		assertEquals(buyer.getBuyerCode(), response.getBody().getBuyerCode());
	}

	@Test
	public void testRetriveBuyerById() {
		headers.setContentType(MediaType.APPLICATION_JSON);
		Buyer buyer = buildBuyerRequest();
		HttpEntity<Buyer> entity = new HttpEntity<>(null, headers);

		ResponseEntity<Buyer> response = restTemplate.exchange(createURLWithPort("/buyer/"+buyer.getId()),
				HttpMethod.GET, entity, Buyer.class);
        assertNotNull(response.getBody());
    	assertNotNull(response);
	}
	
	@Test
	public void testRetrieveAllBuyers()  {
		headers.setContentType(MediaType.APPLICATION_JSON);

		HttpEntity<String> entity = new HttpEntity<>(null, headers);

		ResponseEntity<String> response = restTemplate.exchange(createURLWithPort("/buyer/all"), HttpMethod.GET,
				entity, String.class);
		assertNotNull(response.getBody());
		
	}
	

	@Test
	public void testRemoveSeasonCodesById() {
		headers.setContentType(MediaType.APPLICATION_JSON);
		Buyer buyer = buildBuyerRequest();
		HttpEntity<String> entity = new HttpEntity<>(null, headers);

		ResponseEntity<String> response = restTemplate.exchange(createURLWithPort("/buyer/"+buyer.getId()), HttpMethod.DELETE,
				entity, String.class);
		assertNotNull(response.getBody());
		System.out.println(response.getBody());
	}
	
	@Test
    public void createSeasonCodesInvalidInput() {
		Buyer buyer = buildBuyerRequest();
		buyer.setBuyerCode("");
		headers.setContentType(MediaType.APPLICATION_JSON);
		HttpEntity<Buyer> entity = new HttpEntity<>(buyer, headers);
		ResponseEntity<String> response = restTemplate.exchange(createURLWithPort("/buyer/saveBuyer"),
				HttpMethod.POST, entity, String.class);
		 assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
		 System.out.println(response.getBody());

    }

	private Buyer buildBuyerRequest() {
		Buyer buyer=new Buyer();
		buyer.setId(213l);
		buyer.setBuyerCode("Co1");
		buyer.setBuyerDescription("PCPR5310buyer");
		buyer.setUserId("q134758");
		buyer.setActive("Y");
		buyer.setDirectorCode("077");
		buyer.setDirectorDescription("PCRP5310dir");
		buyer.setVpCode("111");
		buyer.setVpDescription("530");
		buyer.setSales("qvc");
		return buyer;
	}

	private String createURLWithPort(String uri) {
		return "http://localhost:" + port + uri;
	}

}
