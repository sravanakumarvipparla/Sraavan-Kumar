package com.qvc.buyer.app.controller;
import static org.hamcrest.CoreMatchers.hasItem;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.notNullValue;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.ArrayList;
import java.util.List;

import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.MethodSorters;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectWriter;
import com.qvc.buyer.app.exception.BuyerDetailsNotFoundException;
import com.qvc.buyer.app.model.Buyer;
import com.qvc.buyer.app.service.BuyerServiceImpl;


@RunWith(SpringRunner.class)
@WebMvcTest(value = BuyerController.class, secure = false)
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class BuyerControllerTest {
	
	@Autowired
	private MockMvc mockMvc;
	@MockBean
	private BuyerServiceImpl buyerServiceImpl;
	
	private static final String BUYER="/buyer/";


	@Test
	public void findAllBuyersTest() throws Exception {
		List<Buyer> buyersList = buildBuyerList();
		when(buyerServiceImpl.findAllBuyers()).thenReturn(buyersList);
		mockMvc.perform(MockMvcRequestBuilders.get(BUYER+"all").accept(MediaType.APPLICATION_JSON).
		contentType(MediaType.APPLICATION_JSON)).andExpect(status().isOk()).andExpect(MockMvcResultMatchers.jsonPath("$[0].id").value(buyersList.get(0).getId()));
	}
	
	@Test
	public void retriveBuyerByIdTest() throws Exception {
		Buyer buyercodeRequest = buildBuyerRequest();
		Buyer buyercodeResponse = buildBuyerResponse();
		when(buyerServiceImpl.getBuyerById(buyercodeRequest.getId())).thenReturn(buyercodeResponse);
		mockMvc.perform(MockMvcRequestBuilders.get(BUYER+buyercodeRequest.getId()).accept(MediaType.APPLICATION_JSON).
		contentType(MediaType.APPLICATION_JSON)).andExpect(status().isOk()).andExpect(MockMvcResultMatchers.jsonPath("$.id").value(buyercodeRequest.getId()));
	}
	
	@Test
	public void createBuyer() throws Exception {
		Buyer buyercodeRequest = buildBuyerRequest();
		Buyer buyercodeResponse = buildBuyerResponse();
		when(buyerServiceImpl.saveBuyer(buyercodeRequest)).thenReturn(buyercodeResponse); 
		mockMvc.perform(MockMvcRequestBuilders.post(BUYER+"saveBuyer").accept(MediaType.APPLICATION_JSON)
				.content(getJson(buyercodeRequest)).contentType(MediaType.APPLICATION_JSON_UTF8)).andExpect(status().isCreated());		
	}
	
	
	@Test
	public void removeBuyerIdTest() throws Exception {
		Buyer buyercodeRequest = buildBuyerRequest();
		Mockito.doNothing().when(this.buyerServiceImpl).removeBuyer(buyercodeRequest.getId());
		mockMvc.perform(MockMvcRequestBuilders.delete(BUYER+buyercodeRequest.getId()).accept(MediaType.APPLICATION_JSON).
				contentType(MediaType.APPLICATION_JSON)).andExpect(status().isOk());
	}
	
	
	@Test
	public void findBuyerByIdThrowsSeasonCodeNotFoundException() throws Exception {
		Buyer buyerRequest = buildBuyerRequest();
		when(buyerServiceImpl.getBuyerById(buyerRequest.getId())).thenThrow(BuyerDetailsNotFoundException.class);
		mockMvc.perform(MockMvcRequestBuilders.get(BUYER+buyerRequest.getId()).accept(MediaType.APPLICATION_JSON).
		contentType(MediaType.APPLICATION_JSON)).andExpect(status().is4xxClientError());
	}
	
	@Test
	public void testCreateBuyerInvalidRequest() throws Exception {
		Buyer buyerRequest = buildBuyerRequest();
		buyerRequest.setBuyerCode("");
		Buyer buyerCodeResponse = buildBuyerResponse();
		when(buyerServiceImpl.saveBuyer(buyerRequest)).thenReturn(buyerCodeResponse); 
		mockMvc.perform(MockMvcRequestBuilders.post(BUYER+"saveBuyer").accept(MediaType.APPLICATION_JSON)
				.content(getJson(buyerRequest)).contentType(MediaType.APPLICATION_JSON_UTF8)).andExpect(status().is4xxClientError()).andExpect(jsonPath("$.timestamp", is(notNullValue())))
        .andExpect(jsonPath("$.status", is(400)))
        .andExpect(jsonPath("$.errors").isArray())
        .andExpect(jsonPath("$.errors", hasItem("Please provide a buyerCode")));
	}
	
	@Test
	public void removeBuyerByInvalidIdTest() throws Exception {
		Buyer buyerRequest = buildBuyerRequest();
		Mockito.doNothing().when(this.buyerServiceImpl).removeBuyer(buyerRequest.getId());
		mockMvc.perform(MockMvcRequestBuilders.delete(BUYER+"fff").accept(MediaType.APPLICATION_JSON).
				contentType(MediaType.APPLICATION_JSON)).andExpect(status().is4xxClientError());
	}
	
	
	@Test
	public void getSeasonCodeByInvalidIdTest() throws Exception {
		mockMvc.perform(MockMvcRequestBuilders.get(BUYER+"/fff").accept(MediaType.APPLICATION_JSON).
				contentType(MediaType.APPLICATION_JSON)).andExpect(status().is4xxClientError());
	}
	
	private List<Buyer> buildBuyerList() {
		List<Buyer> buyercodesList = new ArrayList<>();
		buyercodesList.add(buildBuyerRequest());
		return buyercodesList;
	}
	
	private byte[] getJson(Object buyerRequest) throws JsonProcessingException {
		ObjectWriter ow = new ObjectMapper().writer().withDefaultPrettyPrinter();
		String json = ow.writeValueAsString(buyerRequest);
		return json.getBytes();
	}
	
	private Buyer buildBuyerRequest() {
		Buyer buyer=new Buyer();
		buyer.setId(213l);
		buyer.setBuyerCode("Co1");
		buyer.setBuyerDescription("PCPR5310buyer");
		buyer.setUserId("q134758");
		buyer.setActive("Y");
		buyer.setDirectorCode("077");
		buyer.setDirectorDescription("PCRP5310dir");
		buyer.setVpCode("111");
		buyer.setVpDescription("530");
		buyer.setSales("qvc");
		return buyer;
	}
	
	
	private Buyer buildBuyerResponse() {
		Buyer buyer=new Buyer();
		buyer.setId(213l);
		return buyer;
	}
	
}
